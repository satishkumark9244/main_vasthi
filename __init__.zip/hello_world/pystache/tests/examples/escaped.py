
"""
TODO: add a docstring.

"""

class Escaped(object):

    def title(self):
        return "Bear > Shark"
